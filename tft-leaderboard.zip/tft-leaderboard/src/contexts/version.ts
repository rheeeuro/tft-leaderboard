import { createContext } from "react";

export const VersionContext = createContext<string>("15.3.1");
