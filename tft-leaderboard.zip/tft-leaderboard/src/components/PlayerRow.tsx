import { VersionContext } from "@/contexts";
import { IPlayer } from "@/model";
import { getElapsedTime, getSummonerIconUrl } from "@/utils";
import { useContext } from "react";
import styled from "@emotion/styled";

interface IProps {
  player: IPlayer;
  refreshPlayer: () => void;
}

const TIER_COLOR = {
  MASTER: "purple",
  DIAMOND: "blue",
  EMERALD: "green",
  PLATINUM: "skyblue",
  GOLD: "gold",
  SILVER: "gray",
  BRONZE: "yellow",
  ICON: "brown",
};
const PLACEMENT_COLOR = [
  "#3fa9f5",
  "#3891d6",
  "#3179b8",
  "#2a6199",
  "#22487a",
  "#1b305b",
  "#14183d",
  "#0d001e",
];
type tierType = keyof typeof TIER_COLOR;

function PlayerRow({ player, refreshPlayer }: IProps) {
  const {
    gameName,
    tagLine,
    updatedAt,
    placements,
    summoner: { profileIconId, summonerLevel },
    league: { tier, rank, leaguePoints, wins, losses },
  } = player;
  const version = useContext(VersionContext);

  return (
    <Container>
      <AvatarContainer>
        <Avatar src={getSummonerIconUrl(version, profileIconId)} />
        <LevelContainer>
          <LevelText>{summonerLevel}</LevelText>
        </LevelContainer>
      </AvatarContainer>
      <InfoContainer>
        <NameTag>
          {gameName}
          <Tag>{`#${tagLine}`}</Tag>
        </NameTag>
        <TierText
          color={TIER_COLOR[tier as tierType]}
        >{`${tier} ${rank} ${leaguePoints}`}</TierText>
        <RecordText>{`${wins}-${losses} (${wins + losses})`}</RecordText>
        <RecordText>{getElapsedTime(updatedAt)}</RecordText>
      </InfoContainer>
      <PlacementGrid>
        {placements.map((placement, index) => (
          <Placement key={index} placement={placement}>
            {placement}
          </Placement>
        ))}
      </PlacementGrid>
      <RefreshButton onClick={refreshPlayer}>🔄</RefreshButton>
    </Container>
  );
}

const Container = styled.div({
  height: "5rem",
  borderBottom: "1px solid black",
  display: "flex",
  alignItems: "center",
  padding: "8px",
});

const AvatarContainer = styled.div({
  width: "4rem",
  height: "4rem",
  borderRadius: "50%",
  overflow: "hidden",
  position: "relative",
  marginRight: "15px",
});

const Avatar = styled.img({
  width: "100%",
  height: "100%",
});

const LevelContainer = styled.div({
  position: "absolute",
  bottom: "0px",
  left: "50%",
  transform: "translateX(-50%)",
  width: "2rem",
  borderRadius: "8px",
  backgroundColor: "#333",
  border: "2px solid #7e8236",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
});

const LevelText = styled.p({
  margin: 0,
  color: "#fff",
  fontSize: "12px",
});

const InfoContainer = styled.div({
  flexGrow: 1,
});

const NameTag = styled.h1({
  fontSize: "18px",
  margin: 0,
});

const Tag = styled.span({
  color: "#aaa",
  fontWeight: 400,
  marginLeft: "5px",
  fontSize: "14px",
});

const TierText = styled.h4<{ color: string }>((props) => ({
  margin: 0,
  fontWeight: 400,
  color: props.color,
}));

const RecordText = styled.p({
  margin: 0,
  color: "#b2b2b2",
});

const PlacementGrid = styled.div({
  display: "grid",
  gridTemplateColumns: "1rem 1rem 1rem 1rem 1rem",
  gridTemplateRows: "1rem 1rem",
  gap: "2px",
  marginRight: "10px",
});

const Placement = styled.div<{ placement: number }>((props) => ({
  width: "1rem",
  height: "1rem",
  borderRadius: "4px",
  backgroundColor: PLACEMENT_COLOR[props.placement - 1] + "99",
  color: "#fff",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  fontSize: "10px",
}));

const RefreshButton = styled.button({
  width: "1.5rem",
  height: "1.5rem",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  fontSize: "1.5rem",
  border: "none",
});

export default PlayerRow;
