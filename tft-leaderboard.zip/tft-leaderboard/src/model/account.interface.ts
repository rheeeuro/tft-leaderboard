export interface AccountDto {
  puuid: string;
  gameName: string;
  tagLine: string;
}
