export * from "@/model/account.interface";
export * from "@/model/league.interface";
export * from "@/model/match.interface";
export * from "@/model/player.interface";
export * from "@/model/summoner.interface";
